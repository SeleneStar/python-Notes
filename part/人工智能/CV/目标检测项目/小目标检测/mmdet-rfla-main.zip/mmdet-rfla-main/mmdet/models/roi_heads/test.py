import torch

A= torch.
# Security

The X-AnyLabeling maintainer team takes security seriously and will actively work to resolve security issues.

## Reporting a vulnerability

If you discover a security vulnerability, please do not open a public issue. Instead, please report it by emailing cv_hub@163.com. We ask that you give us sufficient time to investigate and address the vulnerability before disclosing it publicly.

Please include the following details in your report:
- A description of the vulnerability
- Steps to reproduce the issue
- Your assessment of the potential impact
- Any possible mitigations

## Security best practices

While the maintainer team does their best to secure X-AnyLabeling, users are encouraged to implement their own security best practices, such as:

- Regularly updating to the latest version of X-AnyLabeling
- Securing access to hosted instances of X-AnyLabeling
- Monitoring systems for unusual activity

## Contact

For any other questions or concerns related to security, please contact us at cv_hub@163.com

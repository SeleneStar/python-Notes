pyinstaller --noconfirm anylabeling.spec

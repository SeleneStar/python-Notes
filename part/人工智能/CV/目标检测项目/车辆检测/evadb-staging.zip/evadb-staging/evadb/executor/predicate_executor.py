# coding=utf-8
# Copyright 2018-2023 EvaDB
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import Iterator

from evadb.database import EvaDBDatabase
from evadb.executor.abstract_executor import AbstractExecutor
from evadb.executor.executor_utils import (
    apply_predicate,
    instrument_function_expression_cost,
)
from evadb.models.storage.batch import Batch
from evadb.plan_nodes.predicate_plan import PredicatePlan


class PredicateExecutor(AbstractExecutor):
    """ """

    def __init__(self, db: EvaDBDatabase, node: PredicatePlan):
        super().__init__(db, node)
        self.predicate = node.predicate

    def exec(self, *args, **kwargs) -> Iterator[Batch]:
        child_executor = self.children[0]
        for batch in child_executor.exec(**kwargs):
            batch = apply_predicate(batch, self.predicate)
            if not batch.empty():
                yield batch

        # perform any required instrumentation before we return
        instrument_function_expression_cost(self.predicate, self.catalog())

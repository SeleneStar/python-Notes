# coding=utf-8
# Copyright 2018-2023 EvaDB
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import List

from evadb.catalog.models.column_catalog import ColumnCatalogEntry
from evadb.parser.types import JoinType
from evadb.plan_nodes.abstract_plan import AbstractPlan
from evadb.plan_nodes.types import PlanOprType


class HashJoinBuildPlan(AbstractPlan):
    """
    This plan is used for storing information required for hashjoin build side.
    It prepares the hash table of preferably the smaller relation
    which is used by the probe side to find relevant rows.
    Arguments:
        build_keys (List[ColumnCatalogEntry]) : list of equi-key columns.
                        If empty, then Cartesian product.
    """

    def __init__(self, join_type: JoinType, build_keys: List[ColumnCatalogEntry]):
        self.join_type = join_type
        self.build_keys = build_keys
        super().__init__(PlanOprType.HASH_BUILD)

    def __str__(self):
        return "HashJoinBuildPlan(join_type={}, \
            build_keys={})".format(
            self.join_type, self.build_keys
        )

    def __hash__(self) -> int:
        return hash((super().__hash__(), self.join_type, tuple(self.build_keys or [])))
